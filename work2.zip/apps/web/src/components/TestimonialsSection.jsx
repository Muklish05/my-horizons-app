import React from 'react';
import TestimonialCard from './TestimonialCard';
import ScrollAnimationWrapper from './ScrollAnimationWrapper';

function TestimonialsSection() {
  const testimonials = [
    {
      name: 'Priya Sharma',
      location: 'Guwahati, Assam',
      text: 'The Bombay litchis from Ram Narayan Singh Garden are absolutely divine. The sweetness and texture are unmatched. We visit every season and it never disappoints.',
      rating: 5,
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Priya'
    },
    {
      name: 'Rajesh Kumar',
      location: 'Kolkata, West Bengal',
      text: 'A hidden gem in Tezpur! The variety of litchis available here is incredible. The family has maintained such high standards for generations.',
      rating: 5,
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Rajesh'
    },
    {
      name: 'Ananya Das',
      location: 'Shillong, Meghalaya',
      text: 'Visiting this orchard is a delightful experience. The litchis are fresh, organic, and the hospitality is wonderful. Highly recommend for fruit lovers.',
      rating: 5,
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ananya'
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollAnimationWrapper>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 font-playfair">
              What our visitors say
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Experiences shared by litchi enthusiasts who have visited our garden
            </p>
          </div>
        </ScrollAnimationWrapper>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} testimonial={testimonial} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}

export default TestimonialsSection;
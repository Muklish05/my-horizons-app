import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin } from 'lucide-react';

function AttractionCard({ attraction }) {
  return (
    <Card className="overflow-hidden border-border/50 hover:shadow-lg transition-all duration-300">
      <div className="aspect-video overflow-hidden">
        <img
          src={attraction.image}
          alt={attraction.name}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
        />
      </div>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <MapPin className="h-4 w-4 text-primary" />
          {attraction.name}
        </CardTitle>
        <CardDescription>{attraction.distance}</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {attraction.description}
        </p>
      </CardContent>
    </Card>
  );
}

import React from 'react';
import { Link } from 'react-router-dom';
import { Leaf, Mail, Phone, MapPin, Facebook, Instagram } from 'lucide-react';

function Footer() {
  return (
    <footer className="bg-[#0a0a0a] text-white/90 relative overflow-hidden">
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none mix-blend-soft-light"
        style={{
          backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 400 400\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.9\' numOctaves=\'4\' /%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\' /%3E%3C/svg%3E")'
        }}
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                <Leaf className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <div className="font-bold text-lg font-playfair text-white">
                  Ram Narayan Singh
                </div>
                <div className="text-xs text-white/70">
                  Litchi Garden
                </div>
              </div>
            </div>
            <p className="text-sm leading-relaxed text-white/70">
              Cultivating Assam's finest litchis for over 18 years with dedication to quality and sustainable farming.
            </p>
          </div>

          <div>
            <span className="font-semibold text-sm tracking-wide uppercase mb-4 block text-white">
              Quick Links
            </span>
            <nav className="flex flex-col gap-2">
              {['About', 'Varieties', 'Gallery', 'Visit Us', 'Contact'].map((link) => (
                <Link
                  key={link}
                  to={`/${link.toLowerCase().replace(' ', '-')}`}
                  className="text-sm text-white/70 hover:text-white transition-colors"
                >
                  {link}
                </Link>
              ))}
            </nav>
          </div>

          <div>
            <span className="font-semibold text-sm tracking-wide uppercase mb-4 block text-white">
              Contact
            </span>
            <div className="flex flex-col gap-3">
              <div className="flex items-start gap-2 text-sm">
                <MapPin className="h-4 w-4 mt-0.5 text-primary flex-shrink-0" />
                <span className="text-white/70">Tezpur, Assam, India</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Phone className="h-4 w-4 text-primary flex-shrink-0" />
                <span className="text-white/70">+91 96789 37481</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Mail className="h-4 w-4 text-primary flex-shrink-0" />
                <span className="text-white/70">ramnarayansinghlitchgarden@gmail.com</span>
              </div>
            </div>
          </div>

          <div>
            <span className="font-semibold text-sm tracking-wide uppercase mb-4 block text-white">
              Follow Us
            </span>
            <div className="flex gap-3">
              <a
                href="https://www.facebook.com/profile.php?id=61576634044586"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-all duration-200 active:scale-95"
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="https://www.instagram.com/ramnarayansinghlitchigarden?igsh=MWhpeW1yZDBmZjIwcg=="
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-all duration-200 active:scale-95"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-white/60">
            © 2026 Ram Narayan Singh Litchi Garden. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link to="/privacy" className="text-sm text-white/60 hover:text-white transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms" className="text-sm text-white/60 hover:text-white transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
import React from 'react';
import { motion } from 'framer-motion';
import { useScrollAnimation } from '@/hooks/useScrollAnimation.js';

function TimelineSection() {
  const [ref, isVisible] = useScrollAnimation(0.2);

  const timeline = [
    { year: '1998', event: 'Garden established by Ram Narayan Singh with initial litchi saplings' },
    { year: '2002', event: 'Expanded garden with introduction of rare varieties' },
    { year: '2005', event: 'First major harvest of premium Bombai litchi variety' },
    { year: '2007', event: 'Recognized as one of Assam\'s finest litchi gardens' },
    { year: '2009', event: 'Continuing the legacy with sustainable farming practices' }
  ];

  return (
    <section className="py-20 bg-muted">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 font-playfair">
            Heritage Timeline
          </h2>
          <p className="text-muted-foreground">
            11 years of dedication to excellence in litchi cultivation
          </p>
        </div>

        <div ref={ref} className="relative">
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-0.5 bg-border" />

          {timeline.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
              animate={isVisible ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className={`relative flex items-center mb-12 ${
                index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
              }`}
            >
              <div className={`flex-1 ${index % 2 === 0 ? 'md:text-right md:pr-12' : 'md:pl-12'} pl-16 md:pl-0`}>
                <div className="inline-block bg-card border border-border rounded-2xl p-6 shadow-sm">
                  <div className="text-2xl font-bold text-primary mb-2 font-playfair">
                    {item.year}
                  </div>
                  <p className="text-card-foreground leading-relaxed">
                    {item.event}
                  </p>
                </div>
              </div>

              <div className="absolute left-8 md:left-1/2 w-4 h-4 bg-primary rounded-full -translate-x-1/2 border-4 border-background" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default TimelineSection;
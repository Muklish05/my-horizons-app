import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import GalleryCard from './GalleryCard.jsx';
import LightboxModal from './LightboxModal.jsx';
import ScrollAnimationWrapper from './ScrollAnimationWrapper.jsx';

function GalleryPreview() {
  const navigate = useNavigate();
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const images = [
    { image: 'https://images.unsplash.com/photo-1597713331119-52324f867c72', title: 'Fresh Litchi Harvest' },
    { image: 'https://images.unsplash.com/photo-1595131020664-27a5cb17be4d', title: 'Ripe Litchis on Tree' },
    { image: 'https://images.unsplash.com/photo-1686541980142-32d746b7357c', title: 'Premium Litchi' },
    { image: 'https://images.unsplash.com/photo-1686365518621-dd6d372eb240', title: 'Litchi Tree' },
    { image: 'https://images.unsplash.com/photo-1560770531-7b367ee7667d', title: 'Garden Fresh' },
    { image: 'https://images.unsplash.com/photo-1597713331119-52324f867c72', title: 'Sweet Litchis' }
  ];

  const handleImageClick = (index) => {
    setCurrentImageIndex(index);
    setLightboxOpen(true);
  };

  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollAnimationWrapper>
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 font-playfair">
                18+ years of heritage
              </h2>
              <p className="text-muted-foreground">
                Glimpses of our beautiful garden and premium litchis
              </p>
            </div>
            <Button
              variant="ghost"
              className="group hidden md:flex"
              onClick={() => navigate('/gallery')}
            >
              View All
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </ScrollAnimationWrapper>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {images.map((img, index) => (
            <GalleryCard
              key={index}
              image={img.image}
              title={img.title}
              index={index}
              onClick={() => handleImageClick(index)}
            />
          ))}
        </div>

        <div className="text-center mt-8 md:hidden">
          <Button
            variant="outline"
            className="group"
            onClick={() => navigate('/gallery')}
          >
            View All Photos
            <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>
      </div>

      <LightboxModal
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        images={images}
        currentIndex={currentImageIndex}
        onNavigate={setCurrentImageIndex}
      />
    </section>
  );
}

export default GalleryPreview;
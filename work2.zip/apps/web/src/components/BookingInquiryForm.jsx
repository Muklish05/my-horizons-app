import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

function BookingInquiryForm() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    visitDate: '',
    numberOfPeople: '',
    specialRequests: '',
    honeypot: ''
  });
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    }

    if (!formData.visitDate) {
      newErrors.visitDate = 'Visit date is required';
    }

    if (!formData.numberOfPeople) {
      newErrors.numberOfPeople = 'Number of people is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const sanitizeInput = (input) => {
    return input.replace(/[<>]/g, '');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.honeypot) {
      return;
    }

    if (!validateForm()) {
      return;
    }

    const lastSubmission = localStorage.getItem('lastBookingSubmission');
    if (lastSubmission) {
      const timeSinceLastSubmission = Date.now() - parseInt(lastSubmission);
      if (timeSinceLastSubmission < 60000) {
        toast({
          title: 'Please wait',
          description: 'You can submit the form again in a minute.',
          variant: 'destructive'
        });
        return;
      }
    }

    setIsSubmitting(true);

    try {
      const sanitizedData = {
        name: sanitizeInput(formData.name),
        email: sanitizeInput(formData.email),
        phone: sanitizeInput(formData.phone),
        visitDate: formData.visitDate,
        numberOfPeople: formData.numberOfPeople,
        specialRequests: sanitizeInput(formData.specialRequests),
        timestamp: new Date().toISOString()
      };

      const submissions = JSON.parse(localStorage.getItem('bookingSubmissions') || '[]');
      submissions.push(sanitizedData);
      localStorage.setItem('bookingSubmissions', JSON.stringify(submissions));
      localStorage.setItem('lastBookingSubmission', Date.now().toString());

      await new Promise(resolve => setTimeout(resolve, 1000));

      toast({
        title: 'Inquiry submitted',
        description: 'We have received your visit inquiry. We will contact you shortly to confirm.'
      });

      setFormData({
        name: '',
        email: '',
        phone: '',
        visitDate: '',
        numberOfPeople: '',
        specialRequests: '',
        honeypot: ''
      });
      setErrors({});
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to submit inquiry. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="hidden">
        <input
          type="text"
          name="honeypot"
          value={formData.honeypot}
          onChange={handleChange}
          tabIndex="-1"
          autoComplete="off"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="name">Name</Label>
          <Input
            id="name"
            name="name"
            type="text"
            value={formData.name}
            onChange={handleChange}
            className="mt-2 bg-background text-foreground placeholder:text-muted-foreground"
            placeholder="Your name"
          />
          {errors.name && (
            <p className="text-sm text-destructive mt-1">{errors.name}</p>
          )}
        </div>

        <div>
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            className="mt-2 bg-background text-foreground placeholder:text-muted-foreground"
            placeholder="your.email@example.com"
          />
          {errors.email && (
            <p className="text-sm text-destructive mt-1">{errors.email}</p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="phone">Phone</Label>
          <Input
            id="phone"
            name="phone"
            type="tel"
            value={formData.phone}
            onChange={handleChange}
            className="mt-2 bg-background text-foreground placeholder:text-muted-foreground"
            placeholder="+91 98765 43210"
          />
          {errors.phone && (
            <p className="text-sm text-destructive mt-1">{errors.phone}</p>
          )}
        </div>

        <div>
          <Label htmlFor="visitDate">Preferred visit date</Label>
          <Input
            id="visitDate"
            name="visitDate"
            type="date"
            value={formData.visitDate}
            onChange={handleChange}
            className="mt-2 bg-background text-foreground"
            min={new Date().toISOString().split('T')[0]}
          />
          {errors.visitDate && (
            <p className="text-sm text-destructive mt-1">{errors.visitDate}</p>
          )}
        </div>
      </div>

      <div>
        <Label htmlFor="numberOfPeople">Number of people</Label>
        <Input
          id="numberOfPeople"
          name="numberOfPeople"
          type="number"
          min="1"
          value={formData.numberOfPeople}
          onChange={handleChange}
          className="mt-2 bg-background text-foreground placeholder:text-muted-foreground"
          placeholder="How many people?"
        />
        {errors.numberOfPeople && (
          <p className="text-sm text-destructive mt-1">{errors.numberOfPeople}</p>
        )}
      </div>

      <div>
        <Label htmlFor="specialRequests">Special requests (optional)</Label>
        <Textarea
          id="specialRequests"
          name="specialRequests"
          value={formData.specialRequests}
          onChange={handleChange}
          rows={4}
          className="mt-2 bg-background text-foreground placeholder:text-muted-foreground"
          placeholder="Any special requirements or questions?"
        />
      </div>

      <Button
        type="submit"
        disabled={isSubmitting}
        className="w-full bg-primary text-primary-foreground hover:bg-primary/90 active:scale-[0.98] transition-all duration-200"
      >
        {isSubmitting ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Submitting...
          </>
        ) : (
          'Submit Inquiry'
        )}
      </Button>
    </form>
  );
}

export default BookingInquiryForm;
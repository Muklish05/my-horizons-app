import React from 'react';
import { Button } from '@/components/ui/button';

function FilterBar({ categories, activeCategory, onCategoryChange }) {
  return (
    <div className="flex flex-wrap gap-2">
      <Button
        variant={activeCategory === 'all' ? 'default' : 'outline'}
        onClick={() => onCategoryChange('all')}
        className="transition-all duration-200"
      >
        All Varieties
      </Button>
      {categories.map((category) => (
        <Button
          key={category}
          variant={activeCategory === category ? 'default' : 'outline'}
          onClick={() => onCategoryChange(category)}
          className="transition-all duration-200"
        >
          {category}
        </Button>
      ))}
    </div>
  );
}

export default FilterBar;
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar, Cloud, MapPin, Info } from 'lucide-react';
import ScrollAnimationWrapper from './ScrollAnimationWrapper';

function TravelInfoCards() {
  const infoCards = [
    {
      icon: Calendar,
      title: 'Best visiting season',
      content: 'May to June is peak litchi season. The garden is lush and fruits are at their sweetest during this period.'
    },
    {
      icon: Cloud,
      title: 'Weather',
      content: 'Tezpur enjoys pleasant weather year-round. Summer temperatures range from 25-35°C, perfect for garden visits.'
    },
    {
      icon: MapPin,
      title: 'Getting there',
      content: 'Located 4 km from Tezpur center. Accessible by car, taxi, or local transport. Ample parking available.'
    },
    {
      icon: Info,
      title: 'Visitor tips',
      content: 'Wear comfortable shoes, bring sun protection, and arrive early morning for the best experience and fresh fruit tasting.'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
      {infoCards.map((card, index) => (
        <ScrollAnimationWrapper key={index} delay={index * 0.1}>
          <Card className="h-full border-border/50 hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-lg">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <card.icon className="h-5 w-5 text-primary" />
                </div>
                {card.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                {card.content}
              </p>
            </CardContent>
          </Card>
        </ScrollAnimationWrapper>
      ))}
    </div>
  );
}

export default TravelInfoCards;
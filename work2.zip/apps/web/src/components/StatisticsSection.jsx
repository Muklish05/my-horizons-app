import React from 'react';
import { TreePine, Leaf, Award, Calendar } from 'lucide-react';
import StatCard from './StatCard.jsx';
import ScrollAnimationWrapper from './ScrollAnimationWrapper.jsx';

function StatisticsSection() {
  const stats = [
    { icon: TreePine, number: 500, label: 'Litchi Trees', suffix: '+' },
    { icon: Leaf, number: 9, label: 'Rare Varieties' },
    { icon: Award, number: 1, label: 'Premium Bombai Litchi' },
    { icon: Calendar, number: 18, label: 'Years of Heritage', suffix: '+' }
  ];

  return (
    <section className="py-20 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollAnimationWrapper>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 font-playfair">
              Our legacy in numbers
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Decades of dedication to cultivating the finest litchis in Assam
            </p>
          </div>
        </ScrollAnimationWrapper>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12">
          {stats.map((stat, index) => (
            <StatCard
              key={index}
              icon={stat.icon}
              number={stat.number}
              label={stat.label}
              suffix={stat.suffix}
              delay={index * 0.1}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

export default StatisticsSection;
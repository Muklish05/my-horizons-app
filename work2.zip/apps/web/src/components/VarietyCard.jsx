import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

function VarietyCard({ variety, index = 0, onLearnMore }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ y: -8 }}
      className="h-full"
    >
      <Card className="h-full flex flex-col overflow-hidden border-border/50 hover:shadow-xl transition-all duration-300 bg-card">
        <div className="relative overflow-hidden aspect-[4/3]">
          <motion.img
            src={variety.image}
            alt={variety.name}
            className="w-full h-full object-cover"
            whileHover={{ scale: 1.1 }}
            transition={{ duration: 0.4 }}
          />
          {variety.featured && (
            <Badge className="absolute top-4 right-4 bg-secondary text-secondary-foreground">
              Premium
            </Badge>
          )}
        </div>
        <CardHeader>
          <CardTitle className="text-xl font-playfair">{variety.name}</CardTitle>
          <CardDescription className="line-clamp-2">{variety.description}</CardDescription>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col">
          <div className="flex flex-wrap gap-2 mb-4">
            {variety.tags?.map((tag, i) => (
              <Badge key={i} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>
          <Button 
            variant="ghost" 
            className="mt-auto w-full group"
            onClick={() => onLearnMore?.(variety)}
          >
            Learn More
            <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default VarietyCard;
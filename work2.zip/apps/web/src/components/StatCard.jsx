import React, { useEffect, useState } from 'react';
import { motion, useMotionValue, useTransform, animate } from 'framer-motion';
import { useScrollAnimation } from '@/hooks/useScrollAnimation.js';

function StatCard({ icon: Icon, number, label, suffix = '', delay = 0 }) {
  const [ref, isVisible] = useScrollAnimation(0.2);
  const count = useMotionValue(0);
  const rounded = useTransform(count, Math.round);
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    if (isVisible) {
      const controls = animate(count, number, {
        duration: 2,
        delay,
        ease: [0.25, 0.1, 0.25, 1]
      });

      const unsubscribe = rounded.on('change', (latest) => {
        setDisplayValue(latest);
      });

      return () => {
        controls.stop();
        unsubscribe();
      };
    }
  }, [isVisible, count, number, rounded, delay]);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={isVisible ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay }}
      className="text-center"
    >
      <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 text-primary mb-4">
        <Icon className="h-8 w-8" />
      </div>
      <div className="text-4xl md:text-5xl font-bold text-foreground mb-2 font-playfair">
        {displayValue}{suffix}
      </div>
      <p className="text-muted-foreground font-medium">{label}</p>
    </motion.div>
  );
}

export default StatCard;
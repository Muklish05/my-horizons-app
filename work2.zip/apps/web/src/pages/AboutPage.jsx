import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import ScrollAnimationWrapper from '@/components/ScrollAnimationWrapper.jsx';
import { Droplet, Heart, Award } from 'lucide-react';

function AboutPage() {
  const practices = [
    {
      icon: Droplet,
      title: 'Water conservation',
      description: 'Efficient irrigation systems help us maintain sustainability while nurturing our trees.'
    },
    {
      icon: Heart,
      title: 'Hand-picked care',
      description: 'Each tree receives individual attention, from pruning to harvesting, ensuring premium quality fruit.'
    },
    {
      icon: Award,
      title: 'Quality assurance',
      description: 'Rigorous quality checks at every stage guarantee that only the finest litchis reach our customers.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>About Us - Ram Narayan Singh Litchi Garden</title>
        <meta name="description" content="Learn about our 18+ year heritage of cultivating premium litchis in Tezpur, Assam. Discover our sustainable farming practices and family legacy." />
        <meta property="og:title" content="About Us - Ram Narayan Singh Litchi Garden" />
        <meta property="og:description" content="Learn about our 18+ year heritage of cultivating premium litchis in Tezpur, Assam." />
      </Helmet>

      <Header />

      <main className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumb />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
            <ScrollAnimationWrapper direction="left">
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3]">
                <img
                  src="https://images.unsplash.com/photo-1686541980142-32d746b7357c"
                  alt="Heritage litchi tree in Tezpur, Assam"
                  className="w-full h-full object-cover"
                />
              </div>
            </ScrollAnimationWrapper>

            <ScrollAnimationWrapper direction="right">
              <div>
                <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6 font-playfair leading-tight" style={{ letterSpacing: '-0.02em' }}>
                  A legacy rooted in passion
                </h1>
                <div className="space-y-4 text-muted-foreground leading-relaxed">
                  <p>
                    Ram Narayan Singh Litchi Garden began over 18 years ago with a simple vision: to cultivate the finest litchis in Assam. What started with initial saplings has grown into a thriving garden of over 500 trees, each one nurtured with care and dedication.
                  </p>
                  <p>
                    Our garden is home to 9 rare and premium varieties, including the celebrated Bombai litchi, known for its exceptional sweetness and size. Located in the fertile lands of Tezpur, our garden benefits from the region's ideal climate and rich soil.
                  </p>
                  <p>
                    For over 18 years, we have maintained our commitment to quality farming practices, ensuring that every litchi we grow is not only delicious but also sustainably produced. Our family's passion for quality has made us one of Assam's most respected litchi gardens.
                  </p>
                </div>
              </div>
            </ScrollAnimationWrapper>
          </div>

          <section className="mb-20">
            <ScrollAnimationWrapper>
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 font-playfair">
                  Sustainable farming practices
                </h2>
                <p className="text-muted-foreground max-w-2xl mx-auto">
                  Our commitment to the environment and quality
                </p>
              </div>
            </ScrollAnimationWrapper>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {practices.map((practice, index) => (
                <ScrollAnimationWrapper key={index} delay={index * 0.1}>
                  <div className="flex flex-col gap-4 p-6 rounded-2xl bg-card border border-border/50 hover:shadow-lg transition-all duration-300 h-full">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <practice.icon className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-card-foreground mb-2">
                        {practice.title}
                      </h3>
                      <p className="text-muted-foreground leading-relaxed">
                        {practice.description}
                      </p>
                    </div>
                  </div>
                </ScrollAnimationWrapper>
              ))}
            </div>
          </section>
        </div>
      </main>

      <Footer />
    </>
  );
}

export default AboutPage;
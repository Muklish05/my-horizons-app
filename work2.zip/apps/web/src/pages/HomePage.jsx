import React from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import HeroSection from '@/components/HeroSection.jsx';
import VarietiesCarousel from '@/components/VarietiesCarousel.jsx';
import StatisticsSection from '@/components/StatisticsSection.jsx';
import TestimonialsSection from '@/components/TestimonialsSection.jsx';
import GalleryPreview from '@/components/GalleryPreview.jsx';
import ScrollAnimationWrapper from '@/components/ScrollAnimationWrapper.jsx';

function HomePage() {
  const navigate = useNavigate();

  const featuredVarieties = [
    {
      name: 'Bombai',
      description: 'Our premium variety with exceptional sweetness and large fruit size.',
      image: 'https://images.unsplash.com/photo-1597713331119-52324f867c72',
      tags: ['Premium', 'Sweet'],
      featured: true
    },
    {
      name: 'Billati',
      description: 'A highly sought-after premium variety known for its distinct flavor.',
      image: 'https://images.unsplash.com/photo-1595131020664-27a5cb17be4d',
      tags: ['Premium', 'Sweet']
    },
    {
      name: 'Sahi',
      description: 'Traditional royal variety with robust flavor and excellent taste.',
      image: 'https://images.unsplash.com/photo-1686541980142-32d746b7357c',
      tags: ['Traditional', 'Sweet']
    },
    {
      name: 'Kath Bombay',
      description: 'A traditional favorite with firm texture and balanced sweetness.',
      image: 'https://images.unsplash.com/photo-1686365518621-dd6d372eb240',
      tags: ['Traditional', 'Firm']
    },
    {
      name: 'Rose Scented',
      description: 'Delicate floral aroma with a perfect balance of sweetness.',
      image: 'https://images.unsplash.com/photo-1560770531-7b367ee7667d',
      tags: ['Aromatic', 'Specialty']
    },
    {
      name: 'Piyaji',
      description: 'A uniquely sweet variety that is a favorite among locals.',
      image: 'https://images.unsplash.com/photo-1597713331119-52324f867c72',
      tags: ['Sweet', 'Local Favorite']
    },
    {
      name: 'Elaichi',
      description: 'Small but incredibly flavorful with hints of cardamom.',
      image: 'https://images.unsplash.com/photo-1595131020664-27a5cb17be4d',
      tags: ['Specialty', 'Aromatic']
    },
    {
      name: 'Desi',
      description: 'The classic sweet litchi that started it all.',
      image: 'https://images.unsplash.com/photo-1686541980142-32d746b7357c',
      tags: ['Sweet', 'Classic']
    },
    {
      name: 'Longia',
      description: 'A distinct variety with a slightly elongated shape and great taste.',
      image: 'https://images.unsplash.com/photo-1686365518621-dd6d372eb240',
      tags: ['Specialty', 'Unique']
    }
  ];

  return (
    <>
      <Helmet>
        <title>Ram Narayan Singh Litchi Garden - Assam's Finest Litchi Garden</title>
        <meta name="description" content="Experience the finest litchis from Tezpur, Assam. Over 500 trees, 9 rare varieties including premium Bombai litchi. Visit our heritage garden for an authentic farm experience." />
        <meta property="og:title" content="Ram Narayan Singh Litchi Garden - Assam's Finest Litchi Garden" />
        <meta property="og:description" content="Experience the finest litchis from Tezpur, Assam. Over 500 trees, 9 rare varieties including premium Bombai litchi." />
        <meta property="og:type" content="website" />
      </Helmet>

      <Header />

      <HeroSection
        backgroundImage="https://images.unsplash.com/photo-1665329047469-44225b8bc5ea"
        title="Assam's Finest Litchi Garden"
        subtitle="Experience the sweetness of 500 heritage trees and 9 rare varieties in the heart of Tezpur"
        primaryCTA={{
          text: 'Explore Varieties',
          onClick: () => navigate('/varieties')
        }}
        secondaryCTA={{
          text: 'Plan Your Visit',
          onClick: () => navigate('/visit')
        }}
      />

      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimationWrapper>
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 font-playfair">
                Featured varieties
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Discover our carefully cultivated selection of premium litchi varieties
              </p>
            </div>
          </ScrollAnimationWrapper>

          <VarietiesCarousel varieties={featuredVarieties} />
        </div>
      </section>

      <StatisticsSection />

      <TestimonialsSection />

      <GalleryPreview />

      <Footer />
    </>
  );
}

export default HomePage;
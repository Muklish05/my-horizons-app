import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import VarietyCard from '@/components/VarietyCard.jsx';
import SearchBar from '@/components/SearchBar.jsx';
import FilterBar from '@/components/FilterBar.jsx';
import ScrollAnimationWrapper from '@/components/ScrollAnimationWrapper.jsx';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

function VarietiesPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [selectedVariety, setSelectedVariety] = useState(null);

  const varieties = [
    {
      name: 'Bombai',
      description: 'Our premium variety with exceptional sweetness and large fruit size. Known for its deep red color and juicy flesh.',
      image: 'https://images.unsplash.com/photo-1597713331119-52324f867c72',
      tags: ['Premium', 'Sweet', 'Large'],
      category: 'Premium',
      featured: true,
      details: 'The Bombai litchi is our flagship variety, prized for its large size, deep red skin, and incredibly sweet, juicy flesh. Perfect for fresh consumption.'
    },
    {
      name: 'Billati',
      description: 'A highly sought-after premium variety known for its distinct flavor and excellent quality.',
      image: 'https://images.unsplash.com/photo-1595131020664-27a5cb17be4d',
      tags: ['Premium', 'Sweet'],
      category: 'Premium',
      details: 'Billati is a premium variety that offers a unique taste profile. It is highly valued for its sweetness and premium quality.'
    },
    {
      name: 'Rose Scented',
      description: 'Delicate floral aroma with a perfect balance of sweetness. Medium-sized fruits with thin skin.',
      image: 'https://images.unsplash.com/photo-1686541980142-32d746b7357c',
      tags: ['Aromatic', 'Specialty'],
      category: 'Aromatic',
      details: 'The Rose Scented variety is beloved for its distinctive floral fragrance that fills the air when the fruit is ripe. Offers a unique sensory experience.'
    },
    {
      name: 'Sahi',
      description: 'Traditional royal variety with robust flavor and excellent taste.',
      image: 'https://images.unsplash.com/photo-1686365518621-dd6d372eb240',
      tags: ['Traditional', 'Sweet'],
      category: 'Traditional',
      details: 'A classic traditional variety that has been cultivated for generations. The Sahi litchi offers a robust, sweet flavor profile.'
    },
    {
      name: 'Kath Bombay',
      description: 'A traditional favorite with firm texture and balanced sweetness.',
      image: 'https://images.unsplash.com/photo-1560770531-7b367ee7667d',
      tags: ['Traditional', 'Firm'],
      category: 'Traditional',
      details: 'Kath Bombay is known for its firmer texture and balanced sweetness, making it a traditional favorite among many.'
    },
    {
      name: 'Piyaji',
      description: 'A uniquely sweet variety that is a favorite among locals.',
      image: 'https://images.unsplash.com/photo-1597713331119-52324f867c72',
      tags: ['Sweet', 'Local Favorite'],
      category: 'Sweet',
      details: 'Piyaji is exceptionally sweet and has become a local favorite for its intense flavor and juicy texture.'
    },
    {
      name: 'Desi',
      description: 'The classic sweet litchi that started it all.',
      image: 'https://images.unsplash.com/photo-1595131020664-27a5cb17be4d',
      tags: ['Sweet', 'Classic'],
      category: 'Sweet',
      details: 'The Desi variety represents the classic, sweet litchi taste that everyone loves. A staple in our garden.'
    },
    {
      name: 'Elaichi',
      description: 'Small but incredibly flavorful with hints of cardamom.',
      image: 'https://images.unsplash.com/photo-1686541980142-32d746b7357c',
      tags: ['Specialty', 'Aromatic'],
      category: 'Specialty',
      details: 'Though smaller in size, the Elaichi variety packs an incredible concentration of flavor with subtle aromatic notes.'
    },
    {
      name: 'Longia',
      description: 'A distinct variety with a slightly elongated shape and great taste.',
      image: 'https://images.unsplash.com/photo-1686365518621-dd6d372eb240',
      tags: ['Specialty', 'Unique'],
      category: 'Specialty',
      details: 'Longia is easily recognized by its slightly elongated shape and offers a great, refreshing taste.'
    }
  ];

  const categories = ['Premium', 'Aromatic', 'Traditional', 'Sweet', 'Specialty'];

  const filteredVarieties = useMemo(() => {
    return varieties.filter(variety => {
      const matchesSearch = variety.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          variety.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      let matchesCategory = false;
      if (activeCategory === 'all') {
        matchesCategory = true;
      } else if (activeCategory === 'Premium' && ['Bombai', 'Billati'].includes(variety.name)) {
        matchesCategory = true;
      } else if (activeCategory === 'Aromatic' && ['Rose Scented'].includes(variety.name)) {
        matchesCategory = true;
      } else if (activeCategory === 'Traditional' && ['Sahi', 'Kath Bombay'].includes(variety.name)) {
        matchesCategory = true;
      } else if (activeCategory === 'Sweet' && ['Bombai', 'Billati', 'Sahi', 'Piyaji', 'Desi'].includes(variety.name)) {
        matchesCategory = true;
      } else if (activeCategory === 'Specialty' && ['Bombai', 'Billati', 'Rose Scented'].includes(variety.name)) {
        matchesCategory = true;
      }

      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, activeCategory, varieties]);

  return (
    <>
      <Helmet>
        <title>Litchi Varieties - Ram Narayan Singh Litchi Garden</title>
        <meta name="description" content="Explore our collection of 9 rare litchi varieties including premium Bombai litchi, Rose Scented, and more. Each variety carefully cultivated for exceptional taste." />
        <meta property="og:title" content="Litchi Varieties - Ram Narayan Singh Litchi Garden" />
        <meta property="og:description" content="Explore our collection of 9 rare litchi varieties including premium Bombai litchi, Rose Scented, and more." />
      </Helmet>

      <Header />

      <main className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumb />

          <ScrollAnimationWrapper>
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 font-playfair leading-tight" style={{ letterSpacing: '-0.02em' }}>
                Our litchi varieties
              </h1>
              <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
                Discover 9 carefully cultivated varieties, each with unique characteristics and flavors
              </p>
            </div>
          </ScrollAnimationWrapper>

          <div className="mb-8 flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <SearchBar
                value={searchQuery}
                onChange={setSearchQuery}
                placeholder="Search varieties..."
              />
            </div>
            <div>
              <FilterBar
                categories={categories}
                activeCategory={activeCategory}
                onCategoryChange={setActiveCategory}
              />
            </div>
          </div>

          {filteredVarieties.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-muted-foreground text-lg">
                No varieties found matching your search.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredVarieties.map((variety, index) => (
                <VarietyCard
                  key={index}
                  variety={variety}
                  index={index}
                  onLearnMore={setSelectedVariety}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      <Dialog open={!!selectedVariety} onOpenChange={() => setSelectedVariety(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-playfair">{selectedVariety?.name}</DialogTitle>
            <DialogDescription className="text-base">
              {selectedVariety?.description}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <img
              src={selectedVariety?.image}
              alt={selectedVariety?.name}
              className="w-full h-64 object-cover rounded-xl"
            />
            <p className="text-muted-foreground leading-relaxed">
              {selectedVariety?.details}
            </p>
            <div className="flex flex-wrap gap-2">
              {selectedVariety?.tags?.map((tag, i) => (
                <span
                  key={i}
                  className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Footer />
    </>
  );
}

export default VarietiesPage;
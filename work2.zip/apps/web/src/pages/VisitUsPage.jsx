import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import TravelInfoCards from '@/components/TravelInfoCards.jsx';
import ScrollAnimationWrapper from '@/components/ScrollAnimationWrapper.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Mail } from 'lucide-react';

function VisitUsPage() {
  return (
    <>
      <Helmet>
        <title>Visit Us - Ram Narayan Singh Litchi Garden</title>
        <meta name="description" content="Plan your visit to our litchi garden in Tezpur, Assam. Get directions, travel tips, best visiting times, and book your garden tour. Experience authentic farm tourism." />
        <meta property="og:title" content="Visit Us - Ram Narayan Singh Litchi Garden" />
        <meta property="og:description" content="Plan your visit to our litchi garden in Tezpur, Assam. Get directions, travel tips, and book your garden tour." />
      </Helmet>

      <Header />

      <main className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumb />

          <ScrollAnimationWrapper>
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 font-playfair leading-tight" style={{ letterSpacing: '-0.02em' }}>
                Plan your visit
              </h1>
              <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
                Experience the beauty of our garden and taste the finest litchis in Assam
              </p>
            </div>
          </ScrollAnimationWrapper>

          <TravelInfoCards />

          <div className="grid grid-cols-1 gap-12 mb-20">
            <ScrollAnimationWrapper>
              <Card className="h-full border-border/50">
                <CardHeader>
                  <CardTitle className="text-2xl font-playfair">Getting There</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="aspect-video rounded-xl overflow-hidden mb-6 bg-muted relative shadow-inner">
                    <iframe
                      src="https://maps.google.com/maps?q=Ram%20Narayan%20Singh%20Litchi%20Garden,%20Tezpur,%20Assam&t=&z=15&ie=UTF8&iwloc=&output=embed"
                      className="absolute top-0 left-0 w-full h-full"
                      style={{ border: 0 }}
                      allowFullScreen=""
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                      title="Map showing location of Ram Narayan Singh Litchi Garden in Tezpur, Assam"
                    />
                  </div>
                  <div className="space-y-3 text-muted-foreground">
                    <p className="font-semibold text-foreground text-lg">Ram Narayan Singh Litchi Garden</p>
                    <p className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-primary inline-block"></span>
                      4 km from Tezpur center
                    </p>
                    <p>Tezpur, Sonitpur District</p>
                    <p>Assam 784001, India</p>
                    <div className="pt-4 flex gap-3">
                      <Button
                        variant="outline"
                        className="active:scale-[0.98] transition-all duration-200"
                        onClick={() => window.open('https://maps.app.goo.gl/1fLzBTb96vM54qYH7?g_st=aw', '_blank')}
                      >
                        Open in Google Maps
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </ScrollAnimationWrapper>
          </div>

          <ScrollAnimationWrapper>
            <Card className="mt-12 bg-muted border-border/50">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-bold text-foreground mb-4 font-playfair">
                  Have questions?
                </h3>
                <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                  Feel free to reach out to us via email. We're happy to help plan your perfect visit.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button
                    className="bg-primary text-primary-foreground hover:bg-primary/90 active:scale-[0.98] transition-all duration-200"
                    onClick={() => window.location.href = 'mailto:ramnarayansinghlitchgarden@gmail.com'}
                  >
                    <Mail className="mr-2 h-4 w-4" />
                    Email Us
                  </Button>
                </div>
              </CardContent>
            </Card>
          </ScrollAnimationWrapper>
        </div>
      </main>

      <Footer />
    </>
  );
}

export default VisitUsPage;
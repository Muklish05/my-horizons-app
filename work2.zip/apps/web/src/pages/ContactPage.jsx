import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import FAQItem from '@/components/FAQItem.jsx';
import ScrollAnimationWrapper from '@/components/ScrollAnimationWrapper.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion } from '@/components/ui/accordion';
import { Mail, Phone, MapPin, Facebook, Instagram } from 'lucide-react';
import { Button } from '@/components/ui/button';

function ContactPage() {
  const faqs = [
    {
      question: 'What is the best time to visit the litchi garden?',
      answer: 'The best time to visit is during the peak litchi season from May to June. The fruits are at their sweetest, and the garden is lush and beautiful. However, we welcome visitors year-round to experience the garden in different seasons.'
    },
    {
      question: 'Can I purchase litchis directly from the garden?',
      answer: 'Yes, during the harvest season (May-June), you can purchase fresh litchis directly from our garden. We offer both retail and wholesale options. Please contact us in advance to check availability.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Contact Us - Ram Narayan Singh Litchi Garden</title>
        <meta name="description" content="Get in touch with Ram Narayan Singh Litchi Garden. Contact us for inquiries, bookings, or questions about our litchi varieties and garden visits in Tezpur, Assam." />
        <meta property="og:title" content="Contact Us - Ram Narayan Singh Litchi Garden" />
        <meta property="og:description" content="Get in touch with Ram Narayan Singh Litchi Garden for inquiries, bookings, or questions about our litchi varieties." />
      </Helmet>

      <Header />

      <main className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumb />

          <ScrollAnimationWrapper>
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 font-playfair leading-tight" style={{ letterSpacing: '-0.02em' }}>
                Get in touch
              </h1>
              <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
                We'd love to hear from you. Send us an email and we'll respond as soon as possible.
              </p>
            </div>
          </ScrollAnimationWrapper>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-20 max-w-4xl mx-auto">
            <div className="space-y-6">
              <ScrollAnimationWrapper direction="left">
                <Card className="border-border/50 h-full">
                  <CardHeader>
                    <CardTitle className="text-xl font-playfair">Contact information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-start gap-3">
                      <MapPin className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-card-foreground">Address</p>
                        <p className="text-sm text-muted-foreground">4 km from Tezpur center<br />Tezpur, Sonitpur District<br />Assam 784001, India</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Phone className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-card-foreground">Phone</p>
                        <p className="text-sm text-muted-foreground">+91 96789 37481</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Mail className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-card-foreground">Email</p>
                        <p className="text-sm text-muted-foreground">ramnarayansinghlitchgarden@gmail.com</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </ScrollAnimationWrapper>
            </div>

            <div className="space-y-6">
              <ScrollAnimationWrapper direction="right">
                <Card className="border-border/50">
                  <CardHeader>
                    <CardTitle className="text-xl font-playfair">Quick contact</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button
                      className="w-full bg-primary text-primary-foreground hover:bg-primary/90 active:scale-[0.98] transition-all duration-200"
                      onClick={() => window.location.href = 'mailto:ramnarayansinghlitchgarden@gmail.com'}
                    >
                      <Mail className="mr-2 h-4 w-4" />
                      Email Us
                    </Button>
                  </CardContent>
                </Card>
              </ScrollAnimationWrapper>

              <ScrollAnimationWrapper direction="right" delay={0.1}>
                <Card className="border-border/50">
                  <CardHeader>
                    <CardTitle className="text-xl font-playfair">Follow us</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-3">
                      <a
                        href="https://www.facebook.com/profile.php?id=61576634044586"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-12 h-12 rounded-xl bg-muted hover:bg-primary hover:text-primary-foreground flex items-center justify-center transition-all duration-200 active:scale-95"
                        aria-label="Facebook"
                      >
                        <Facebook className="h-5 w-5" />
                      </a>
                      <a
                        href="https://www.instagram.com/ramnarayansinghlitchigarden?igsh=MWhpeW1yZDBmZjIwcg=="
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-12 h-12 rounded-xl bg-muted hover:bg-primary hover:text-primary-foreground flex items-center justify-center transition-all duration-200 active:scale-95"
                        aria-label="Instagram"
                      >
                        <Instagram className="h-5 w-5" />
                      </a>
                    </div>
                  </CardContent>
                </Card>
              </ScrollAnimationWrapper>
            </div>
          </div>

          <section>
            <ScrollAnimationWrapper>
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 font-playfair">
                  Frequently asked questions
                </h2>
                <p className="text-muted-foreground max-w-2xl mx-auto">
                  Find answers to common questions about visiting our garden
                </p>
              </div>
            </ScrollAnimationWrapper>

            <div className="max-w-3xl mx-auto">
              <Accordion type="single" collapsible className="space-y-4">
                {faqs.map((faq, index) => (
                  <FAQItem
                    key={index}
                    question={faq.question}
                    answer={faq.answer}
                    value={`item-${index}`}
                  />
                ))}
              </Accordion>
            </div>
          </section>
        </div>
      </main>

      <Footer />
    </>
  );
}

export default ContactPage;
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import GalleryCard from '@/components/GalleryCard.jsx';
import LightboxModal from '@/components/LightboxModal.jsx';
import ScrollAnimationWrapper from '@/components/ScrollAnimationWrapper.jsx';
import { Skeleton } from '@/components/ui/skeleton';

function GalleryPage() {
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [imagesLoaded, setImagesLoaded] = useState(false);

  React.useEffect(() => {
    const timer = setTimeout(() => setImagesLoaded(true), 500);
    return () => clearTimeout(timer);
  }, []);

  const galleryImages = [
    { image: 'https://images.unsplash.com/photo-1597713331119-52324f867c72', title: 'Fresh Litchi Harvest' },
    { image: 'https://images.unsplash.com/photo-1595131020664-27a5cb17be4d', title: 'Ripe Litchis on Tree' },
    { image: 'https://images.unsplash.com/photo-1686541980142-32d746b7357c', title: 'Premium Litchi' },
    { image: 'https://images.unsplash.com/photo-1686365518621-dd6d372eb240', title: 'Litchi Tree' },
    { image: 'https://images.unsplash.com/photo-1560770531-7b367ee7667d', title: 'Garden Fresh' },
    { image: 'https://images.unsplash.com/photo-1597713331119-52324f867c72', title: 'Sweet Litchis' },
    { image: 'https://images.unsplash.com/photo-1595131020664-27a5cb17be4d', title: 'Bombai Litchi Close-up' },
    { image: 'https://images.unsplash.com/photo-1686541980142-32d746b7357c', title: 'Rose Scented Variety' },
    { image: 'https://images.unsplash.com/photo-1686365518621-dd6d372eb240', title: 'Harvest Season' }
  ];

  const handleImageClick = (index) => {
    setCurrentImageIndex(index);
    setLightboxOpen(true);
  };

  return (
    <>
      <Helmet>
        <title>Gallery - Ram Narayan Singh Litchi Garden</title>
        <meta name="description" content="Browse our photo gallery showcasing the beauty of our litchi garden, harvest seasons, and premium varieties. Experience the visual journey of our heritage garden." />
        <meta property="og:title" content="Gallery - Ram Narayan Singh Litchi Garden" />
        <meta property="og:description" content="Browse our photo gallery showcasing the beauty of our litchi garden, harvest seasons, and premium varieties." />
      </Helmet>

      <Header />

      <main className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumb />

          <ScrollAnimationWrapper>
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 font-playfair leading-tight" style={{ letterSpacing: '-0.02em' }}>
                Photo gallery
              </h1>
              <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
                Explore the beauty of our garden and premium litchis
              </p>
            </div>
          </ScrollAnimationWrapper>

          {!imagesLoaded ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {[...Array(9)].map((_, i) => (
                <Skeleton key={i} className="aspect-square rounded-2xl" />
              ))}
            </div>
          ) : (
            <div className="columns-1 md:columns-2 lg:columns-3 gap-4 space-y-4">
              {galleryImages.map((img, index) => (
                <div key={index} className="break-inside-avoid">
                  <GalleryCard
                    image={img.image}
                    title={img.title}
                    index={index}
                    onClick={() => handleImageClick(index)}
                  />
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      <LightboxModal
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        images={galleryImages}
        currentIndex={currentImageIndex}
        onNavigate={setCurrentImageIndex}
      />

      <Footer />
    </>
  );
}

export default GalleryPage;